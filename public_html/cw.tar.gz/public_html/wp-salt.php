<?php
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 */
define('AUTH_KEY',         'J6XQ3oQ6iyNgHsznDtMDJzJSuw6zLWJ6uhYKTTw2XcwK03sDQUftUWxKC4tSUxmi');
define('SECURE_AUTH_KEY',  'mxeQr63UeRhTVUIUvjNFbAiIfjGUVGLEcPVQwYnfYESzM8JWIhc6FenmAuDpSTpP');
define('LOGGED_IN_KEY',    'INLCJnpwUVns9vL1YHbtWzCV5H1GuzmQPC9zVJ5EGEKKNhjGhxVevSLzNoLco1CK');
define('NONCE_KEY',        'xRGUobTJexLEaRnW6GTJiAFQ2M94BfyfS7mz2MumzPsnJMdSJI5qddXbJUnYWFJI');
define('AUTH_SALT',        'LH5DVuc4E53RusGT2aKMvaNz03zNYtAAgE7uVqxWTi3yo9o6Ut7M0uamv4uWczgx');
define('SECURE_AUTH_SALT', 'jswbhDifGJBdYEjSNQuEqqYMvqWU9NgNV2xEqyae3aUCYxDaPEeuG5LApEWjY0Li');
define('LOGGED_IN_SALT',   '9jWv8aTNHXd8pN6IJwV15D0UHUo3oeUC6bJRYW1a4JQ218VHaTiaBdmHWQTUxuuz');
define('NONCE_SALT',       'gmcQWCitNnoco8vB5Lj0pzeMQyhg2n5pPbwCga8rXF2N8oIoUrA1gyyY8iKu6j8U');
